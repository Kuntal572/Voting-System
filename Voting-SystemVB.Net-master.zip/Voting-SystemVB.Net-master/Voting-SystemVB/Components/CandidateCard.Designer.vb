﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CandidateCard
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CandidateCard))
        Me.Guna2CustomGradientPanel1 = New Guna.UI2.WinForms.Guna2CustomGradientPanel()
        Me.ButtonEdit = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2PictureBox2 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.LabelTagline = New System.Windows.Forms.Label()
        Me.LabelStudentID = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LabelYear = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.LabelCourse = New System.Windows.Forms.Label()
        Me.LabelFullname = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.LabelParty = New System.Windows.Forms.Label()
        Me.LabelPosition = New System.Windows.Forms.Label()
        Me.Guna2CustomGradientPanel1.SuspendLayout()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2CustomGradientPanel1
        '
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.ButtonEdit)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2PictureBox2)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2PictureBox1)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.LabelTagline)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.LabelStudentID)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Label1)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.LabelYear)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Label4)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.LabelCourse)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.LabelFullname)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Label3)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Label5)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.LabelParty)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.LabelPosition)
        Me.Guna2CustomGradientPanel1.CustomBorderColor = System.Drawing.Color.Gray
        Me.Guna2CustomGradientPanel1.CustomBorderThickness = New System.Windows.Forms.Padding(1)
        Me.Guna2CustomGradientPanel1.FillColor = System.Drawing.Color.FromArgb(CType(CType(207, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Guna2CustomGradientPanel1.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Guna2CustomGradientPanel1.Location = New System.Drawing.Point(5, 5)
        Me.Guna2CustomGradientPanel1.Name = "Guna2CustomGradientPanel1"
        Me.Guna2CustomGradientPanel1.ShadowDecoration.Parent = Me.Guna2CustomGradientPanel1
        Me.Guna2CustomGradientPanel1.Size = New System.Drawing.Size(276, 374)
        Me.Guna2CustomGradientPanel1.TabIndex = 7
        '
        'ButtonEdit
        '
        Me.ButtonEdit.CheckedState.Parent = Me.ButtonEdit
        Me.ButtonEdit.CustomImages.Parent = Me.ButtonEdit
        Me.ButtonEdit.FillColor = System.Drawing.Color.Transparent
        Me.ButtonEdit.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ButtonEdit.ForeColor = System.Drawing.Color.White
        Me.ButtonEdit.HoverState.Parent = Me.ButtonEdit
        Me.ButtonEdit.Image = CType(resources.GetObject("ButtonEdit.Image"), System.Drawing.Image)
        Me.ButtonEdit.ImageSize = New System.Drawing.Size(24, 24)
        Me.ButtonEdit.Location = New System.Drawing.Point(67, 169)
        Me.ButtonEdit.Name = "ButtonEdit"
        Me.ButtonEdit.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.ButtonEdit.ShadowDecoration.Parent = Me.ButtonEdit
        Me.ButtonEdit.Size = New System.Drawing.Size(24, 24)
        Me.ButtonEdit.TabIndex = 19
        Me.ButtonEdit.Visible = False
        '
        'Guna2PictureBox2
        '
        Me.Guna2PictureBox2.BackColor = System.Drawing.Color.Gray
        Me.Guna2PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Guna2PictureBox2.ErrorImage = Global.Voting_SystemVB.My.Resources.Resources.error_image
        Me.Guna2PictureBox2.Location = New System.Drawing.Point(15, 120)
        Me.Guna2PictureBox2.Name = "Guna2PictureBox2"
        Me.Guna2PictureBox2.ShadowDecoration.Parent = Me.Guna2PictureBox2
        Me.Guna2PictureBox2.Size = New System.Drawing.Size(75, 75)
        Me.Guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox2.TabIndex = 20
        Me.Guna2PictureBox2.TabStop = False
        '
        'Guna2PictureBox1
        '
        Me.Guna2PictureBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Guna2PictureBox1.ErrorImage = Global.Voting_SystemVB.My.Resources.Resources.error_image
        Me.Guna2PictureBox1.FillColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Guna2PictureBox1.Location = New System.Drawing.Point(1, 1)
        Me.Guna2PictureBox1.Name = "Guna2PictureBox1"
        Me.Guna2PictureBox1.ShadowDecoration.Parent = Me.Guna2PictureBox1
        Me.Guna2PictureBox1.Size = New System.Drawing.Size(274, 148)
        Me.Guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox1.TabIndex = 18
        Me.Guna2PictureBox1.TabStop = False
        '
        'LabelTagline
        '
        Me.LabelTagline.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LabelTagline.Font = New System.Drawing.Font("Century Gothic", 10.0!, System.Drawing.FontStyle.Italic)
        Me.LabelTagline.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.LabelTagline.Location = New System.Drawing.Point(12, 332)
        Me.LabelTagline.Name = "LabelTagline"
        Me.LabelTagline.Size = New System.Drawing.Size(254, 33)
        Me.LabelTagline.TabIndex = 7
        Me.LabelTagline.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelStudentID
        '
        Me.LabelStudentID.AutoSize = True
        Me.LabelStudentID.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.LabelStudentID.ForeColor = System.Drawing.Color.Black
        Me.LabelStudentID.Location = New System.Drawing.Point(97, 309)
        Me.LabelStudentID.Name = "LabelStudentID"
        Me.LabelStudentID.Size = New System.Drawing.Size(89, 19)
        Me.LabelStudentID.TabIndex = 8
        Me.LabelStudentID.Text = "20191012-C"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(11, 309)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 19)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "StudentID:"
        '
        'LabelYear
        '
        Me.LabelYear.AutoSize = True
        Me.LabelYear.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.LabelYear.ForeColor = System.Drawing.Color.Black
        Me.LabelYear.Location = New System.Drawing.Point(60, 288)
        Me.LabelYear.Name = "LabelYear"
        Me.LabelYear.Size = New System.Drawing.Size(70, 19)
        Me.LabelYear.TabIndex = 10
        Me.LabelYear.Text = "2nd Year"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(11, 288)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 19)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Year:"
        '
        'LabelCourse
        '
        Me.LabelCourse.AutoSize = True
        Me.LabelCourse.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.LabelCourse.ForeColor = System.Drawing.Color.Black
        Me.LabelCourse.Location = New System.Drawing.Point(77, 269)
        Me.LabelCourse.Name = "LabelCourse"
        Me.LabelCourse.Size = New System.Drawing.Size(42, 19)
        Me.LabelCourse.TabIndex = 12
        Me.LabelCourse.Text = "BSCS"
        '
        'LabelFullname
        '
        Me.LabelFullname.AutoSize = True
        Me.LabelFullname.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.LabelFullname.Location = New System.Drawing.Point(11, 196)
        Me.LabelFullname.Name = "LabelFullname"
        Me.LabelFullname.Size = New System.Drawing.Size(187, 19)
        Me.LabelFullname.TabIndex = 13
        Me.LabelFullname.Text = "Lenard Mangay-ayam"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(11, 269)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 19)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Course:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(11, 250)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(48, 19)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Party:"
        '
        'LabelParty
        '
        Me.LabelParty.AutoSize = True
        Me.LabelParty.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.LabelParty.ForeColor = System.Drawing.Color.Black
        Me.LabelParty.Location = New System.Drawing.Point(60, 250)
        Me.LabelParty.Name = "LabelParty"
        Me.LabelParty.Size = New System.Drawing.Size(101, 19)
        Me.LabelParty.TabIndex = 16
        Me.LabelParty.Text = "Independent"
        '
        'LabelPosition
        '
        Me.LabelPosition.AutoSize = True
        Me.LabelPosition.Font = New System.Drawing.Font("Century Gothic", 10.0!)
        Me.LabelPosition.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.LabelPosition.Location = New System.Drawing.Point(11, 215)
        Me.LabelPosition.Name = "LabelPosition"
        Me.LabelPosition.Size = New System.Drawing.Size(95, 19)
        Me.LabelPosition.TabIndex = 17
        Me.LabelPosition.Text = "For President"
        '
        'CandidateCard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Transparent
        Me.Controls.Add(Me.Guna2CustomGradientPanel1)
        Me.Margin = New System.Windows.Forms.Padding(10)
        Me.MaximumSize = New System.Drawing.Size(286, 384)
        Me.Name = "CandidateCard"
        Me.Size = New System.Drawing.Size(286, 384)
        Me.Guna2CustomGradientPanel1.ResumeLayout(False)
        Me.Guna2CustomGradientPanel1.PerformLayout()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Guna2CustomGradientPanel1 As Guna.UI2.WinForms.Guna2CustomGradientPanel
    Friend WithEvents ButtonEdit As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Guna2PictureBox2 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents LabelTagline As System.Windows.Forms.Label
    Friend WithEvents LabelStudentID As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LabelYear As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents LabelCourse As System.Windows.Forms.Label
    Friend WithEvents LabelFullname As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents LabelParty As System.Windows.Forms.Label
    Friend WithEvents LabelPosition As System.Windows.Forms.Label

End Class
