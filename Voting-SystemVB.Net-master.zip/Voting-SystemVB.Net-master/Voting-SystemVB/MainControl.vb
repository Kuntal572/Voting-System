﻿Public Interface MainControl

    Sub RefreshControl()

End Interface
