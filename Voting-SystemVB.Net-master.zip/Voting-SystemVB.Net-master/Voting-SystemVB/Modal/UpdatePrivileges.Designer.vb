﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UpdatePrivileges
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2GroupBox1 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.TextYourPassword = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextFullname = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CBUsername = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ErrorYourPassword = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Guna2ToggleSwitch1 = New Guna.UI2.WinForms.Guna2ToggleSwitch()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Guna2ToggleSwitch4 = New Guna.UI2.WinForms.Guna2ToggleSwitch()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Guna2ToggleSwitch2 = New Guna.UI2.WinForms.Guna2ToggleSwitch()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Guna2ToggleSwitch5 = New Guna.UI2.WinForms.Guna2ToggleSwitch()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Guna2ToggleSwitch3 = New Guna.UI2.WinForms.Guna2ToggleSwitch()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Guna2ToggleSwitch9 = New Guna.UI2.WinForms.Guna2ToggleSwitch()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Guna2ToggleSwitch6 = New Guna.UI2.WinForms.Guna2ToggleSwitch()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Guna2VSeparator1 = New Guna.UI2.WinForms.Guna2VSeparator()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ErrorPassword = New System.Windows.Forms.Label()
        Me.ErrorUsername = New System.Windows.Forms.Label()
        Me.ErrorFullname = New System.Windows.Forms.Label()
        Me.ButtonCancel = New Guna.UI2.WinForms.Guna2Button()
        Me.ButtonSubmit = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2GroupBox1.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'Guna2GroupBox1
        '
        Me.Guna2GroupBox1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(164, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Guna2GroupBox1.Controls.Add(Me.TextYourPassword)
        Me.Guna2GroupBox1.Controls.Add(Me.Label3)
        Me.Guna2GroupBox1.Controls.Add(Me.TextFullname)
        Me.Guna2GroupBox1.Controls.Add(Me.Label2)
        Me.Guna2GroupBox1.Controls.Add(Me.CBUsername)
        Me.Guna2GroupBox1.Controls.Add(Me.Label1)
        Me.Guna2GroupBox1.Controls.Add(Me.ErrorYourPassword)
        Me.Guna2GroupBox1.Controls.Add(Me.FlowLayoutPanel1)
        Me.Guna2GroupBox1.Controls.Add(Me.Guna2VSeparator1)
        Me.Guna2GroupBox1.Controls.Add(Me.Label4)
        Me.Guna2GroupBox1.Controls.Add(Me.ErrorPassword)
        Me.Guna2GroupBox1.Controls.Add(Me.ErrorUsername)
        Me.Guna2GroupBox1.Controls.Add(Me.ErrorFullname)
        Me.Guna2GroupBox1.Controls.Add(Me.ButtonCancel)
        Me.Guna2GroupBox1.Controls.Add(Me.ButtonSubmit)
        Me.Guna2GroupBox1.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(164, Byte), Integer), CType(CType(91, Byte), Integer))
        Me.Guna2GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Guna2GroupBox1.FillColor = System.Drawing.SystemColors.Control
        Me.Guna2GroupBox1.Font = New System.Drawing.Font("Segoe UI", 16.0!)
        Me.Guna2GroupBox1.ForeColor = System.Drawing.Color.White
        Me.Guna2GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2GroupBox1.Name = "Guna2GroupBox1"
        Me.Guna2GroupBox1.ShadowDecoration.Parent = Me.Guna2GroupBox1
        Me.Guna2GroupBox1.Size = New System.Drawing.Size(709, 513)
        Me.Guna2GroupBox1.TabIndex = 28
        Me.Guna2GroupBox1.Text = "Update Sub Admin Privileges"
        '
        'TextYourPassword
        '
        Me.TextYourPassword.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextYourPassword.DefaultText = ""
        Me.TextYourPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TextYourPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TextYourPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TextYourPassword.DisabledState.Parent = Me.TextYourPassword
        Me.TextYourPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TextYourPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextYourPassword.FocusedState.Parent = Me.TextYourPassword
        Me.TextYourPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextYourPassword.HoverState.Parent = Me.TextYourPassword
        Me.TextYourPassword.Location = New System.Drawing.Point(25, 291)
        Me.TextYourPassword.Margin = New System.Windows.Forms.Padding(6, 7, 6, 7)
        Me.TextYourPassword.Name = "TextYourPassword"
        Me.TextYourPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TextYourPassword.PlaceholderText = ""
        Me.TextYourPassword.SelectedText = ""
        Me.TextYourPassword.ShadowDecoration.Parent = Me.TextYourPassword
        Me.TextYourPassword.Size = New System.Drawing.Size(318, 36)
        Me.TextYourPassword.TabIndex = 45
        Me.TextYourPassword.UseSystemPasswordChar = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 14.0!)
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(20, 259)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(227, 25)
        Me.Label3.TabIndex = 44
        Me.Label3.Text = "Enter your password here"
        '
        'TextFullname
        '
        Me.TextFullname.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextFullname.DefaultText = ""
        Me.TextFullname.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(213, Byte), Integer), CType(CType(218, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.TextFullname.DisabledState.FillColor = System.Drawing.Color.White
        Me.TextFullname.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.TextFullname.DisabledState.Parent = Me.TextFullname
        Me.TextFullname.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TextFullname.Enabled = False
        Me.TextFullname.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextFullname.FocusedState.Parent = Me.TextFullname
        Me.TextFullname.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextFullname.HoverState.Parent = Me.TextFullname
        Me.TextFullname.Location = New System.Drawing.Point(25, 179)
        Me.TextFullname.Margin = New System.Windows.Forms.Padding(6, 7, 6, 7)
        Me.TextFullname.Name = "TextFullname"
        Me.TextFullname.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TextFullname.PlaceholderText = ""
        Me.TextFullname.SelectedText = ""
        Me.TextFullname.ShadowDecoration.Parent = Me.TextFullname
        Me.TextFullname.Size = New System.Drawing.Size(318, 36)
        Me.TextFullname.TabIndex = 43
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 14.0!)
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(20, 154)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 25)
        Me.Label2.TabIndex = 42
        Me.Label2.Text = "Fullname"
        '
        'CBUsername
        '
        Me.CBUsername.BackColor = System.Drawing.Color.Transparent
        Me.CBUsername.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.CBUsername.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CBUsername.FocusedColor = System.Drawing.Color.Empty
        Me.CBUsername.FocusedState.Parent = Me.CBUsername
        Me.CBUsername.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.CBUsername.ForeColor = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(112, Byte), Integer))
        Me.CBUsername.FormattingEnabled = True
        Me.CBUsername.HoverState.Parent = Me.CBUsername
        Me.CBUsername.ItemHeight = 30
        Me.CBUsername.ItemsAppearance.Parent = Me.CBUsername
        Me.CBUsername.Location = New System.Drawing.Point(25, 94)
        Me.CBUsername.Name = "CBUsername"
        Me.CBUsername.ShadowDecoration.Parent = Me.CBUsername
        Me.CBUsername.Size = New System.Drawing.Size(318, 36)
        Me.CBUsername.TabIndex = 41
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 14.0!)
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(20, 66)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(97, 25)
        Me.Label1.TabIndex = 40
        Me.Label1.Text = "Username"
        '
        'ErrorYourPassword
        '
        Me.ErrorYourPassword.AutoSize = True
        Me.ErrorYourPassword.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.ErrorYourPassword.ForeColor = System.Drawing.Color.Red
        Me.ErrorYourPassword.Location = New System.Drawing.Point(22, 453)
        Me.ErrorYourPassword.Name = "ErrorYourPassword"
        Me.ErrorYourPassword.Size = New System.Drawing.Size(0, 13)
        Me.ErrorYourPassword.TabIndex = 39
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel1)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel4)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel2)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel5)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel3)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel9)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel6)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(381, 98)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(300, 313)
        Me.FlowLayoutPanel1.TabIndex = 37
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Guna2ToggleSwitch1)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(0, 0, 0, 15)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(296, 29)
        Me.Panel1.TabIndex = 34
        '
        'Guna2ToggleSwitch1
        '
        Me.Guna2ToggleSwitch1.Animated = True
        Me.Guna2ToggleSwitch1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2ToggleSwitch1.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2ToggleSwitch1.CheckedState.InnerBorderColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch1.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch1.CheckedState.Parent = Me.Guna2ToggleSwitch1
        Me.Guna2ToggleSwitch1.Location = New System.Drawing.Point(3, 3)
        Me.Guna2ToggleSwitch1.Name = "Guna2ToggleSwitch1"
        Me.Guna2ToggleSwitch1.ShadowDecoration.Parent = Me.Guna2ToggleSwitch1
        Me.Guna2ToggleSwitch1.Size = New System.Drawing.Size(35, 20)
        Me.Guna2ToggleSwitch1.TabIndex = 33
        Me.Guna2ToggleSwitch1.Tag = "2"
        Me.Guna2ToggleSwitch1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2ToggleSwitch1.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2ToggleSwitch1.UncheckedState.InnerBorderColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch1.UncheckedState.InnerColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch1.UncheckedState.Parent = Me.Guna2ToggleSwitch1
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(44, 3)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(118, 21)
        Me.Label6.TabIndex = 31
        Me.Label6.Text = "Can Add Voters"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Guna2ToggleSwitch4)
        Me.Panel4.Controls.Add(Me.Label9)
        Me.Panel4.Location = New System.Drawing.Point(0, 44)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(0, 0, 0, 15)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(296, 29)
        Me.Panel4.TabIndex = 34
        '
        'Guna2ToggleSwitch4
        '
        Me.Guna2ToggleSwitch4.Animated = True
        Me.Guna2ToggleSwitch4.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2ToggleSwitch4.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2ToggleSwitch4.CheckedState.InnerBorderColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch4.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch4.CheckedState.Parent = Me.Guna2ToggleSwitch4
        Me.Guna2ToggleSwitch4.Location = New System.Drawing.Point(3, 3)
        Me.Guna2ToggleSwitch4.Name = "Guna2ToggleSwitch4"
        Me.Guna2ToggleSwitch4.ShadowDecoration.Parent = Me.Guna2ToggleSwitch4
        Me.Guna2ToggleSwitch4.Size = New System.Drawing.Size(35, 20)
        Me.Guna2ToggleSwitch4.TabIndex = 33
        Me.Guna2ToggleSwitch4.Tag = "5"
        Me.Guna2ToggleSwitch4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2ToggleSwitch4.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2ToggleSwitch4.UncheckedState.InnerBorderColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch4.UncheckedState.InnerColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch4.UncheckedState.Parent = Me.Guna2ToggleSwitch4
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(44, 3)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(251, 21)
        Me.Label9.TabIndex = 31
        Me.Label9.Text = "Can Update Candidate Information"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Guna2ToggleSwitch2)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Location = New System.Drawing.Point(0, 88)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(0, 0, 0, 15)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(296, 29)
        Me.Panel2.TabIndex = 35
        '
        'Guna2ToggleSwitch2
        '
        Me.Guna2ToggleSwitch2.Animated = True
        Me.Guna2ToggleSwitch2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2ToggleSwitch2.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2ToggleSwitch2.CheckedState.InnerBorderColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch2.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch2.CheckedState.Parent = Me.Guna2ToggleSwitch2
        Me.Guna2ToggleSwitch2.Location = New System.Drawing.Point(3, 3)
        Me.Guna2ToggleSwitch2.Name = "Guna2ToggleSwitch2"
        Me.Guna2ToggleSwitch2.ShadowDecoration.Parent = Me.Guna2ToggleSwitch2
        Me.Guna2ToggleSwitch2.Size = New System.Drawing.Size(35, 20)
        Me.Guna2ToggleSwitch2.TabIndex = 33
        Me.Guna2ToggleSwitch2.Tag = "3"
        Me.Guna2ToggleSwitch2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2ToggleSwitch2.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2ToggleSwitch2.UncheckedState.InnerBorderColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch2.UncheckedState.InnerColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch2.UncheckedState.Parent = Me.Guna2ToggleSwitch2
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(44, 3)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(226, 21)
        Me.Label7.TabIndex = 31
        Me.Label7.Text = "Can Update Voters Information"
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.Guna2ToggleSwitch5)
        Me.Panel5.Controls.Add(Me.Label10)
        Me.Panel5.Location = New System.Drawing.Point(0, 132)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(0, 0, 0, 15)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(296, 29)
        Me.Panel5.TabIndex = 35
        '
        'Guna2ToggleSwitch5
        '
        Me.Guna2ToggleSwitch5.Animated = True
        Me.Guna2ToggleSwitch5.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2ToggleSwitch5.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2ToggleSwitch5.CheckedState.InnerBorderColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch5.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch5.CheckedState.Parent = Me.Guna2ToggleSwitch5
        Me.Guna2ToggleSwitch5.Location = New System.Drawing.Point(3, 3)
        Me.Guna2ToggleSwitch5.Name = "Guna2ToggleSwitch5"
        Me.Guna2ToggleSwitch5.ShadowDecoration.Parent = Me.Guna2ToggleSwitch5
        Me.Guna2ToggleSwitch5.Size = New System.Drawing.Size(35, 20)
        Me.Guna2ToggleSwitch5.TabIndex = 33
        Me.Guna2ToggleSwitch5.Tag = "7"
        Me.Guna2ToggleSwitch5.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2ToggleSwitch5.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2ToggleSwitch5.UncheckedState.InnerBorderColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch5.UncheckedState.InnerColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch5.UncheckedState.Parent = Me.Guna2ToggleSwitch5
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(44, 3)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(109, 21)
        Me.Label10.TabIndex = 31
        Me.Label10.Text = "Can Add Party"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Guna2ToggleSwitch3)
        Me.Panel3.Controls.Add(Me.Label8)
        Me.Panel3.Location = New System.Drawing.Point(0, 176)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(0, 0, 0, 15)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(296, 29)
        Me.Panel3.TabIndex = 36
        '
        'Guna2ToggleSwitch3
        '
        Me.Guna2ToggleSwitch3.Animated = True
        Me.Guna2ToggleSwitch3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2ToggleSwitch3.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2ToggleSwitch3.CheckedState.InnerBorderColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch3.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch3.CheckedState.Parent = Me.Guna2ToggleSwitch3
        Me.Guna2ToggleSwitch3.Location = New System.Drawing.Point(3, 3)
        Me.Guna2ToggleSwitch3.Name = "Guna2ToggleSwitch3"
        Me.Guna2ToggleSwitch3.ShadowDecoration.Parent = Me.Guna2ToggleSwitch3
        Me.Guna2ToggleSwitch3.Size = New System.Drawing.Size(35, 20)
        Me.Guna2ToggleSwitch3.TabIndex = 33
        Me.Guna2ToggleSwitch3.Tag = "4"
        Me.Guna2ToggleSwitch3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2ToggleSwitch3.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2ToggleSwitch3.UncheckedState.InnerBorderColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch3.UncheckedState.InnerColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch3.UncheckedState.Parent = Me.Guna2ToggleSwitch3
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(44, 3)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(172, 21)
        Me.Label8.TabIndex = 31
        Me.Label8.Text = "Can Register Candidate"
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.Guna2ToggleSwitch9)
        Me.Panel9.Controls.Add(Me.Label14)
        Me.Panel9.Location = New System.Drawing.Point(0, 220)
        Me.Panel9.Margin = New System.Windows.Forms.Padding(0, 0, 0, 15)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(296, 29)
        Me.Panel9.TabIndex = 36
        '
        'Guna2ToggleSwitch9
        '
        Me.Guna2ToggleSwitch9.Animated = True
        Me.Guna2ToggleSwitch9.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2ToggleSwitch9.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2ToggleSwitch9.CheckedState.InnerBorderColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch9.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch9.CheckedState.Parent = Me.Guna2ToggleSwitch9
        Me.Guna2ToggleSwitch9.Location = New System.Drawing.Point(3, 3)
        Me.Guna2ToggleSwitch9.Name = "Guna2ToggleSwitch9"
        Me.Guna2ToggleSwitch9.ShadowDecoration.Parent = Me.Guna2ToggleSwitch9
        Me.Guna2ToggleSwitch9.Size = New System.Drawing.Size(35, 20)
        Me.Guna2ToggleSwitch9.TabIndex = 33
        Me.Guna2ToggleSwitch9.Tag = "10"
        Me.Guna2ToggleSwitch9.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2ToggleSwitch9.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2ToggleSwitch9.UncheckedState.InnerBorderColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch9.UncheckedState.InnerColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch9.UncheckedState.Parent = Me.Guna2ToggleSwitch9
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label14.Location = New System.Drawing.Point(44, 3)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(132, 21)
        Me.Label14.TabIndex = 31
        Me.Label14.Text = "Can Start Election"
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.Guna2ToggleSwitch6)
        Me.Panel6.Controls.Add(Me.Label11)
        Me.Panel6.Location = New System.Drawing.Point(0, 264)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(0, 0, 0, 15)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(296, 29)
        Me.Panel6.TabIndex = 36
        '
        'Guna2ToggleSwitch6
        '
        Me.Guna2ToggleSwitch6.Animated = True
        Me.Guna2ToggleSwitch6.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2ToggleSwitch6.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2ToggleSwitch6.CheckedState.InnerBorderColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch6.CheckedState.InnerColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch6.CheckedState.Parent = Me.Guna2ToggleSwitch6
        Me.Guna2ToggleSwitch6.Location = New System.Drawing.Point(3, 3)
        Me.Guna2ToggleSwitch6.Name = "Guna2ToggleSwitch6"
        Me.Guna2ToggleSwitch6.ShadowDecoration.Parent = Me.Guna2ToggleSwitch6
        Me.Guna2ToggleSwitch6.Size = New System.Drawing.Size(35, 20)
        Me.Guna2ToggleSwitch6.TabIndex = 33
        Me.Guna2ToggleSwitch6.Tag = "8"
        Me.Guna2ToggleSwitch6.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2ToggleSwitch6.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2ToggleSwitch6.UncheckedState.InnerBorderColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch6.UncheckedState.InnerColor = System.Drawing.Color.White
        Me.Guna2ToggleSwitch6.UncheckedState.Parent = Me.Guna2ToggleSwitch6
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(44, 3)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(217, 21)
        Me.Label11.TabIndex = 31
        Me.Label11.Text = "Can Update Party Information"
        '
        'Guna2VSeparator1
        '
        Me.Guna2VSeparator1.Location = New System.Drawing.Point(365, 66)
        Me.Guna2VSeparator1.Name = "Guna2VSeparator1"
        Me.Guna2VSeparator1.Size = New System.Drawing.Size(10, 345)
        Me.Guna2VSeparator1.TabIndex = 32
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 14.0!)
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(380, 66)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(93, 25)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "Privileges"
        '
        'ErrorPassword
        '
        Me.ErrorPassword.AutoSize = True
        Me.ErrorPassword.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.ErrorPassword.ForeColor = System.Drawing.Color.Red
        Me.ErrorPassword.Location = New System.Drawing.Point(22, 349)
        Me.ErrorPassword.Name = "ErrorPassword"
        Me.ErrorPassword.Size = New System.Drawing.Size(0, 13)
        Me.ErrorPassword.TabIndex = 28
        '
        'ErrorUsername
        '
        Me.ErrorUsername.AutoSize = True
        Me.ErrorUsername.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.ErrorUsername.ForeColor = System.Drawing.Color.Red
        Me.ErrorUsername.Location = New System.Drawing.Point(22, 246)
        Me.ErrorUsername.Name = "ErrorUsername"
        Me.ErrorUsername.Size = New System.Drawing.Size(0, 13)
        Me.ErrorUsername.TabIndex = 26
        '
        'ErrorFullname
        '
        Me.ErrorFullname.AutoSize = True
        Me.ErrorFullname.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.ErrorFullname.ForeColor = System.Drawing.Color.Red
        Me.ErrorFullname.Location = New System.Drawing.Point(22, 141)
        Me.ErrorFullname.Name = "ErrorFullname"
        Me.ErrorFullname.Size = New System.Drawing.Size(0, 13)
        Me.ErrorFullname.TabIndex = 24
        '
        'ButtonCancel
        '
        Me.ButtonCancel.BackColor = System.Drawing.Color.Transparent
        Me.ButtonCancel.CheckedState.Parent = Me.ButtonCancel
        Me.ButtonCancel.CustomImages.Parent = Me.ButtonCancel
        Me.ButtonCancel.FillColor = System.Drawing.Color.Transparent
        Me.ButtonCancel.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.ButtonCancel.ForeColor = System.Drawing.Color.Gray
        Me.ButtonCancel.HoverState.Parent = Me.ButtonCancel
        Me.ButtonCancel.Location = New System.Drawing.Point(432, 459)
        Me.ButtonCancel.Name = "ButtonCancel"
        Me.ButtonCancel.ShadowDecoration.Parent = Me.ButtonCancel
        Me.ButtonCancel.Size = New System.Drawing.Size(93, 22)
        Me.ButtonCancel.TabIndex = 20
        Me.ButtonCancel.Text = "Cancel"
        '
        'ButtonSubmit
        '
        Me.ButtonSubmit.Animated = True
        Me.ButtonSubmit.CheckedState.Parent = Me.ButtonSubmit
        Me.ButtonSubmit.CustomImages.Parent = Me.ButtonSubmit
        Me.ButtonSubmit.FillColor = System.Drawing.Color.FromArgb(CType(CType(71, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.ButtonSubmit.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.ButtonSubmit.ForeColor = System.Drawing.Color.White
        Me.ButtonSubmit.HoverState.Parent = Me.ButtonSubmit
        Me.ButtonSubmit.Location = New System.Drawing.Point(531, 453)
        Me.ButtonSubmit.Name = "ButtonSubmit"
        Me.ButtonSubmit.ShadowDecoration.Parent = Me.ButtonSubmit
        Me.ButtonSubmit.Size = New System.Drawing.Size(150, 36)
        Me.ButtonSubmit.TabIndex = 21
        Me.ButtonSubmit.Text = "Submit"
        '
        'UpdatePrivileges
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Guna2GroupBox1)
        Me.Name = "UpdatePrivileges"
        Me.Size = New System.Drawing.Size(709, 513)
        Me.Guna2GroupBox1.ResumeLayout(False)
        Me.Guna2GroupBox1.PerformLayout()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Guna2GroupBox1 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents ErrorYourPassword As System.Windows.Forms.Label
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Guna2ToggleSwitch1 As Guna.UI2.WinForms.Guna2ToggleSwitch
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Guna2ToggleSwitch4 As Guna.UI2.WinForms.Guna2ToggleSwitch
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Guna2ToggleSwitch2 As Guna.UI2.WinForms.Guna2ToggleSwitch
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Guna2ToggleSwitch5 As Guna.UI2.WinForms.Guna2ToggleSwitch
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Guna2ToggleSwitch3 As Guna.UI2.WinForms.Guna2ToggleSwitch
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents Guna2ToggleSwitch9 As Guna.UI2.WinForms.Guna2ToggleSwitch
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Guna2ToggleSwitch6 As Guna.UI2.WinForms.Guna2ToggleSwitch
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Guna2VSeparator1 As Guna.UI2.WinForms.Guna2VSeparator
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ErrorPassword As System.Windows.Forms.Label
    Friend WithEvents ErrorUsername As System.Windows.Forms.Label
    Friend WithEvents ErrorFullname As System.Windows.Forms.Label
    Friend WithEvents ButtonCancel As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents ButtonSubmit As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents CBUsername As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextYourPassword As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextFullname As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label

End Class
