﻿Public Class ErrorResult

End Class
