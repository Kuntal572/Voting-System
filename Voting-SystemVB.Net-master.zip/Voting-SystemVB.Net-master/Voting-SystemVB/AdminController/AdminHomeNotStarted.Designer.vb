﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminHomeNotStarted
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Guna2ShadowPanel1 = New Guna.UI2.WinForms.Guna2ShadowPanel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.FontAwesome1 = New Voting_SystemVB.FontAwesome()
        Me.LabelVotersCount = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnVoter = New Guna.UI2.WinForms.Guna2ImageButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Guna2ShadowPanel2 = New Guna.UI2.WinForms.Guna2ShadowPanel()
        Me.FontAwesome2 = New Voting_SystemVB.FontAwesome()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.LabelPreviousElection = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.BtnPreviousElection = New Guna.UI2.WinForms.Guna2ImageButton()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Guna2ShadowPanel3 = New Guna.UI2.WinForms.Guna2ShadowPanel()
        Me.FontAwesome3 = New Voting_SystemVB.FontAwesome()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.LabelParties = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.BtnParties = New Guna.UI2.WinForms.Guna2ImageButton()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Guna2ShadowPanel4 = New Guna.UI2.WinForms.Guna2ShadowPanel()
        Me.FontAwesome4 = New Voting_SystemVB.FontAwesome()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LabelCandidates = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.BtnCandidates = New Guna.UI2.WinForms.Guna2ImageButton()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Guna2ShadowPanel5 = New Guna.UI2.WinForms.Guna2ShadowPanel()
        Me.Guna2GradientPanel1 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ButtonStartElection = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.FontAwesome5 = New Voting_SystemVB.FontAwesome()
        Me.Guna2ShadowPanel6 = New Guna.UI2.WinForms.Guna2ShadowPanel()
        Me.Guna2GradientPanel2 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.ButtonImport = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.FontAwesome6 = New Voting_SystemVB.FontAwesome()
        Me.Guna2WinProgressIndicator1 = New Guna.UI2.WinForms.Guna2WinProgressIndicator()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.LoadingPanel = New System.Windows.Forms.Panel()
        Me.BackgroundWorkerFetchData = New System.ComponentModel.BackgroundWorker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.Guna2ShadowPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Guna2ShadowPanel2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Guna2ShadowPanel3.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Guna2ShadowPanel4.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Guna2ShadowPanel5.SuspendLayout()
        Me.Guna2GradientPanel1.SuspendLayout()
        Me.Guna2ShadowPanel6.SuspendLayout()
        Me.Guna2GradientPanel2.SuspendLayout()
        Me.LoadingPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel1.AutoSize = True
        Me.FlowLayoutPanel1.BackColor = System.Drawing.Color.Transparent
        Me.FlowLayoutPanel1.Controls.Add(Me.Guna2ShadowPanel1)
        Me.FlowLayoutPanel1.Controls.Add(Me.Guna2ShadowPanel2)
        Me.FlowLayoutPanel1.Controls.Add(Me.Guna2ShadowPanel3)
        Me.FlowLayoutPanel1.Controls.Add(Me.Guna2ShadowPanel4)
        Me.FlowLayoutPanel1.Controls.Add(Me.Guna2ShadowPanel5)
        Me.FlowLayoutPanel1.Controls.Add(Me.Guna2ShadowPanel6)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(36, 86)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(868, 266)
        Me.FlowLayoutPanel1.TabIndex = 0
        '
        'Guna2ShadowPanel1
        '
        Me.Guna2ShadowPanel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2ShadowPanel1.Controls.Add(Me.Label2)
        Me.Guna2ShadowPanel1.Controls.Add(Me.FontAwesome1)
        Me.Guna2ShadowPanel1.Controls.Add(Me.LabelVotersCount)
        Me.Guna2ShadowPanel1.Controls.Add(Me.Panel1)
        Me.Guna2ShadowPanel1.FillColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Guna2ShadowPanel1.Location = New System.Drawing.Point(3, 3)
        Me.Guna2ShadowPanel1.Name = "Guna2ShadowPanel1"
        Me.Guna2ShadowPanel1.ShadowColor = System.Drawing.Color.Black
        Me.Guna2ShadowPanel1.Size = New System.Drawing.Size(279, 127)
        Me.Guna2ShadowPanel1.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(15, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(106, 15)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Total No. of Voters"
        '
        'FontAwesome1
        '
        Me.FontAwesome1.AutoSize = True
        Me.FontAwesome1.Font = New System.Drawing.Font("Font Awesome 5 Free Solid", 36.0!)
        Me.FontAwesome1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.FontAwesome1.HoverColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.FontAwesome1.IsHoverable = False
        Me.FontAwesome1.Location = New System.Drawing.Point(187, 22)
        Me.FontAwesome1.Name = "FontAwesome1"
        Me.FontAwesome1.Size = New System.Drawing.Size(64, 51)
        Me.FontAwesome1.TabIndex = 4
        Me.FontAwesome1.Text = "user"
        '
        'LabelVotersCount
        '
        Me.LabelVotersCount.AutoSize = True
        Me.LabelVotersCount.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold)
        Me.LabelVotersCount.ForeColor = System.Drawing.Color.White
        Me.LabelVotersCount.Location = New System.Drawing.Point(12, 22)
        Me.LabelVotersCount.Name = "LabelVotersCount"
        Me.LabelVotersCount.Size = New System.Drawing.Size(29, 32)
        Me.LabelVotersCount.TabIndex = 3
        Me.LabelVotersCount.Text = "0"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel1.Controls.Add(Me.btnVoter)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(5, 89)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(269, 32)
        Me.Panel1.TabIndex = 0
        '
        'btnVoter
        '
        Me.btnVoter.BackColor = System.Drawing.Color.Transparent
        Me.btnVoter.CheckedState.Parent = Me.btnVoter
        Me.btnVoter.HoverState.Parent = Me.btnVoter
        Me.btnVoter.Image = Global.Voting_SystemVB.My.Resources.Resources.arrow_circle_right_white
        Me.btnVoter.ImageSize = New System.Drawing.Size(15, 15)
        Me.btnVoter.Location = New System.Drawing.Point(152, 9)
        Me.btnVoter.Name = "btnVoter"
        Me.btnVoter.PressedState.Parent = Me.btnVoter
        Me.btnVoter.Size = New System.Drawing.Size(15, 15)
        Me.btnVoter.TabIndex = 2
        Me.btnVoter.Tag = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Bold)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(93, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "More Info"
        '
        'Guna2ShadowPanel2
        '
        Me.Guna2ShadowPanel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2ShadowPanel2.Controls.Add(Me.FontAwesome2)
        Me.Guna2ShadowPanel2.Controls.Add(Me.Label4)
        Me.Guna2ShadowPanel2.Controls.Add(Me.LabelPreviousElection)
        Me.Guna2ShadowPanel2.Controls.Add(Me.Panel2)
        Me.Guna2ShadowPanel2.FillColor = System.Drawing.Color.FromArgb(CType(CType(55, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.Guna2ShadowPanel2.Location = New System.Drawing.Point(288, 3)
        Me.Guna2ShadowPanel2.Name = "Guna2ShadowPanel2"
        Me.Guna2ShadowPanel2.ShadowColor = System.Drawing.Color.Black
        Me.Guna2ShadowPanel2.Size = New System.Drawing.Size(279, 127)
        Me.Guna2ShadowPanel2.TabIndex = 6
        '
        'FontAwesome2
        '
        Me.FontAwesome2.AutoSize = True
        Me.FontAwesome2.Font = New System.Drawing.Font("Font Awesome 5 Free Solid", 36.0!)
        Me.FontAwesome2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.FontAwesome2.HoverColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.FontAwesome2.IsHoverable = False
        Me.FontAwesome2.Location = New System.Drawing.Point(181, 22)
        Me.FontAwesome2.Name = "FontAwesome2"
        Me.FontAwesome2.Size = New System.Drawing.Size(70, 51)
        Me.FontAwesome2.TabIndex = 4
        Me.FontAwesome2.Text = "list"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(15, 58)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(102, 15)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Previous Elections"
        '
        'LabelPreviousElection
        '
        Me.LabelPreviousElection.AutoSize = True
        Me.LabelPreviousElection.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold)
        Me.LabelPreviousElection.ForeColor = System.Drawing.Color.White
        Me.LabelPreviousElection.Location = New System.Drawing.Point(12, 22)
        Me.LabelPreviousElection.Name = "LabelPreviousElection"
        Me.LabelPreviousElection.Size = New System.Drawing.Size(29, 32)
        Me.LabelPreviousElection.TabIndex = 3
        Me.LabelPreviousElection.Text = "0"
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel2.Controls.Add(Me.BtnPreviousElection)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Location = New System.Drawing.Point(5, 89)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(269, 32)
        Me.Panel2.TabIndex = 0
        '
        'BtnPreviousElection
        '
        Me.BtnPreviousElection.BackColor = System.Drawing.Color.Transparent
        Me.BtnPreviousElection.CheckedState.Parent = Me.BtnPreviousElection
        Me.BtnPreviousElection.HoverState.Parent = Me.BtnPreviousElection
        Me.BtnPreviousElection.Image = Global.Voting_SystemVB.My.Resources.Resources.arrow_circle_right_white
        Me.BtnPreviousElection.ImageSize = New System.Drawing.Size(15, 15)
        Me.BtnPreviousElection.Location = New System.Drawing.Point(152, 9)
        Me.BtnPreviousElection.Name = "BtnPreviousElection"
        Me.BtnPreviousElection.PressedState.Parent = Me.BtnPreviousElection
        Me.BtnPreviousElection.Size = New System.Drawing.Size(15, 15)
        Me.BtnPreviousElection.TabIndex = 2
        Me.BtnPreviousElection.Tag = "done voters"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Bold)
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(93, 10)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 13)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "More Info"
        '
        'Guna2ShadowPanel3
        '
        Me.Guna2ShadowPanel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2ShadowPanel3.Controls.Add(Me.FontAwesome3)
        Me.Guna2ShadowPanel3.Controls.Add(Me.Label7)
        Me.Guna2ShadowPanel3.Controls.Add(Me.LabelParties)
        Me.Guna2ShadowPanel3.Controls.Add(Me.Panel3)
        Me.Guna2ShadowPanel3.FillColor = System.Drawing.Color.Purple
        Me.Guna2ShadowPanel3.Location = New System.Drawing.Point(573, 3)
        Me.Guna2ShadowPanel3.Name = "Guna2ShadowPanel3"
        Me.Guna2ShadowPanel3.ShadowColor = System.Drawing.Color.Black
        Me.Guna2ShadowPanel3.Size = New System.Drawing.Size(279, 127)
        Me.Guna2ShadowPanel3.TabIndex = 7
        '
        'FontAwesome3
        '
        Me.FontAwesome3.AutoSize = True
        Me.FontAwesome3.Font = New System.Drawing.Font("Font Awesome 5 Free Solid", 36.0!)
        Me.FontAwesome3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(103, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.FontAwesome3.HoverColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.FontAwesome3.IsHoverable = False
        Me.FontAwesome3.Location = New System.Drawing.Point(169, 22)
        Me.FontAwesome3.Name = "FontAwesome3"
        Me.FontAwesome3.Size = New System.Drawing.Size(82, 51)
        Me.FontAwesome3.TabIndex = 4
        Me.FontAwesome3.Text = "users"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(15, 58)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(108, 15)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "Total No. of Parties" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'LabelParties
        '
        Me.LabelParties.AutoSize = True
        Me.LabelParties.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold)
        Me.LabelParties.ForeColor = System.Drawing.Color.White
        Me.LabelParties.Location = New System.Drawing.Point(12, 22)
        Me.LabelParties.Name = "LabelParties"
        Me.LabelParties.Size = New System.Drawing.Size(29, 32)
        Me.LabelParties.TabIndex = 3
        Me.LabelParties.Text = "0"
        '
        'Panel3
        '
        Me.Panel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel3.Controls.Add(Me.BtnParties)
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Location = New System.Drawing.Point(5, 89)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(269, 32)
        Me.Panel3.TabIndex = 0
        '
        'BtnParties
        '
        Me.BtnParties.BackColor = System.Drawing.Color.Transparent
        Me.BtnParties.CheckedState.Parent = Me.BtnParties
        Me.BtnParties.HoverState.Parent = Me.BtnParties
        Me.BtnParties.Image = Global.Voting_SystemVB.My.Resources.Resources.arrow_circle_right_white
        Me.BtnParties.ImageSize = New System.Drawing.Size(15, 15)
        Me.BtnParties.Location = New System.Drawing.Point(152, 9)
        Me.BtnParties.Name = "BtnParties"
        Me.BtnParties.PressedState.Parent = Me.BtnParties
        Me.BtnParties.Size = New System.Drawing.Size(15, 15)
        Me.BtnParties.TabIndex = 2
        Me.BtnParties.Tag = "remaining voters"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Bold)
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(93, 10)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(59, 13)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "More Info"
        '
        'Guna2ShadowPanel4
        '
        Me.Guna2ShadowPanel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2ShadowPanel4.Controls.Add(Me.FontAwesome4)
        Me.Guna2ShadowPanel4.Controls.Add(Me.Label3)
        Me.Guna2ShadowPanel4.Controls.Add(Me.LabelCandidates)
        Me.Guna2ShadowPanel4.Controls.Add(Me.Panel4)
        Me.Guna2ShadowPanel4.FillColor = System.Drawing.Color.Brown
        Me.Guna2ShadowPanel4.Location = New System.Drawing.Point(3, 136)
        Me.Guna2ShadowPanel4.Name = "Guna2ShadowPanel4"
        Me.Guna2ShadowPanel4.ShadowColor = System.Drawing.Color.Black
        Me.Guna2ShadowPanel4.Size = New System.Drawing.Size(279, 127)
        Me.Guna2ShadowPanel4.TabIndex = 8
        '
        'FontAwesome4
        '
        Me.FontAwesome4.AutoSize = True
        Me.FontAwesome4.Font = New System.Drawing.Font("Font Awesome 5 Free Solid", 36.0!)
        Me.FontAwesome4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(133, Byte), Integer), CType(CType(34, Byte), Integer), CType(CType(34, Byte), Integer))
        Me.FontAwesome4.HoverColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(104, Byte), Integer))
        Me.FontAwesome4.IsHoverable = False
        Me.FontAwesome4.Location = New System.Drawing.Point(187, 22)
        Me.FontAwesome4.Name = "FontAwesome4"
        Me.FontAwesome4.Size = New System.Drawing.Size(64, 51)
        Me.FontAwesome4.TabIndex = 4
        Me.FontAwesome4.Text = "user-tie"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(15, 58)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(132, 15)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Total No. of Candidates"
        '
        'LabelCandidates
        '
        Me.LabelCandidates.AutoSize = True
        Me.LabelCandidates.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold)
        Me.LabelCandidates.ForeColor = System.Drawing.Color.White
        Me.LabelCandidates.Location = New System.Drawing.Point(12, 22)
        Me.LabelCandidates.Name = "LabelCandidates"
        Me.LabelCandidates.Size = New System.Drawing.Size(29, 32)
        Me.LabelCandidates.TabIndex = 3
        Me.LabelCandidates.Text = "0"
        '
        'Panel4
        '
        Me.Panel4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel4.Controls.Add(Me.BtnCandidates)
        Me.Panel4.Controls.Add(Me.Label8)
        Me.Panel4.Location = New System.Drawing.Point(5, 89)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(269, 32)
        Me.Panel4.TabIndex = 0
        '
        'BtnCandidates
        '
        Me.BtnCandidates.BackColor = System.Drawing.Color.Transparent
        Me.BtnCandidates.CheckedState.Parent = Me.BtnCandidates
        Me.BtnCandidates.HoverState.Parent = Me.BtnCandidates
        Me.BtnCandidates.Image = Global.Voting_SystemVB.My.Resources.Resources.arrow_circle_right_white
        Me.BtnCandidates.ImageSize = New System.Drawing.Size(15, 15)
        Me.BtnCandidates.Location = New System.Drawing.Point(152, 9)
        Me.BtnCandidates.Name = "BtnCandidates"
        Me.BtnCandidates.PressedState.Parent = Me.BtnCandidates
        Me.BtnCandidates.Size = New System.Drawing.Size(15, 15)
        Me.BtnCandidates.TabIndex = 2
        Me.BtnCandidates.Tag = "remaining voters"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Bold)
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(93, 10)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 13)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "More Info"
        '
        'Guna2ShadowPanel5
        '
        Me.Guna2ShadowPanel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2ShadowPanel5.Controls.Add(Me.Guna2GradientPanel1)
        Me.Guna2ShadowPanel5.FillColor = System.Drawing.Color.White
        Me.Guna2ShadowPanel5.Location = New System.Drawing.Point(288, 136)
        Me.Guna2ShadowPanel5.Name = "Guna2ShadowPanel5"
        Me.Guna2ShadowPanel5.ShadowColor = System.Drawing.Color.Black
        Me.Guna2ShadowPanel5.Size = New System.Drawing.Size(279, 127)
        Me.Guna2ShadowPanel5.TabIndex = 9
        '
        'Guna2GradientPanel1
        '
        Me.Guna2GradientPanel1.Controls.Add(Me.Label10)
        Me.Guna2GradientPanel1.Controls.Add(Me.ButtonStartElection)
        Me.Guna2GradientPanel1.Controls.Add(Me.FontAwesome5)
        Me.Guna2GradientPanel1.FillColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(222, Byte), Integer), CType(CType(218, Byte), Integer))
        Me.Guna2GradientPanel1.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(201, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.Guna2GradientPanel1.Location = New System.Drawing.Point(5, 5)
        Me.Guna2GradientPanel1.Name = "Guna2GradientPanel1"
        Me.Guna2GradientPanel1.ShadowDecoration.Parent = Me.Guna2GradientPanel1
        Me.Guna2GradientPanel1.Size = New System.Drawing.Size(269, 119)
        Me.Guna2GradientPanel1.TabIndex = 0
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Century Gothic", 18.0!)
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(18, 17)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(109, 60)
        Me.Label10.TabIndex = 4
        Me.Label10.Text = "Start " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Election"
        '
        'ButtonStartElection
        '
        Me.ButtonStartElection.Animated = True
        Me.ButtonStartElection.CheckedState.Parent = Me.ButtonStartElection
        Me.ButtonStartElection.CustomImages.Parent = Me.ButtonStartElection
        Me.ButtonStartElection.FillColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ButtonStartElection.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ButtonStartElection.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ButtonStartElection.ForeColor = System.Drawing.Color.White
        Me.ButtonStartElection.HoverState.Parent = Me.ButtonStartElection
        Me.ButtonStartElection.Location = New System.Drawing.Point(0, 87)
        Me.ButtonStartElection.Name = "ButtonStartElection"
        Me.ButtonStartElection.ShadowDecoration.Parent = Me.ButtonStartElection
        Me.ButtonStartElection.Size = New System.Drawing.Size(269, 32)
        Me.ButtonStartElection.TabIndex = 1
        Me.ButtonStartElection.Text = "START NOW"
        '
        'FontAwesome5
        '
        Me.FontAwesome5.AutoSize = True
        Me.FontAwesome5.Font = New System.Drawing.Font("Font Awesome 5 Free Solid", 36.0!)
        Me.FontAwesome5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(160, Byte), Integer))
        Me.FontAwesome5.HoverColor = System.Drawing.Color.Empty
        Me.FontAwesome5.IsHoverable = False
        Me.FontAwesome5.Location = New System.Drawing.Point(182, 17)
        Me.FontAwesome5.Name = "FontAwesome5"
        Me.FontAwesome5.Size = New System.Drawing.Size(64, 51)
        Me.FontAwesome5.TabIndex = 0
        Me.FontAwesome5.Text = "calendar-check"
        '
        'Guna2ShadowPanel6
        '
        Me.Guna2ShadowPanel6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2ShadowPanel6.Controls.Add(Me.Guna2GradientPanel2)
        Me.Guna2ShadowPanel6.FillColor = System.Drawing.Color.White
        Me.Guna2ShadowPanel6.Location = New System.Drawing.Point(573, 136)
        Me.Guna2ShadowPanel6.Name = "Guna2ShadowPanel6"
        Me.Guna2ShadowPanel6.ShadowColor = System.Drawing.Color.Black
        Me.Guna2ShadowPanel6.Size = New System.Drawing.Size(279, 127)
        Me.Guna2ShadowPanel6.TabIndex = 10
        '
        'Guna2GradientPanel2
        '
        Me.Guna2GradientPanel2.Controls.Add(Me.Label11)
        Me.Guna2GradientPanel2.Controls.Add(Me.ButtonImport)
        Me.Guna2GradientPanel2.Controls.Add(Me.FontAwesome6)
        Me.Guna2GradientPanel2.FillColor = System.Drawing.Color.FromArgb(CType(CType(238, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(167, Byte), Integer))
        Me.Guna2GradientPanel2.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(221, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.Guna2GradientPanel2.Location = New System.Drawing.Point(5, 5)
        Me.Guna2GradientPanel2.Name = "Guna2GradientPanel2"
        Me.Guna2GradientPanel2.ShadowDecoration.Parent = Me.Guna2GradientPanel2
        Me.Guna2GradientPanel2.Size = New System.Drawing.Size(269, 119)
        Me.Guna2GradientPanel2.TabIndex = 0
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Century Gothic", 17.0!)
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(8, 19)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(161, 54)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "Import " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Student Data"
        '
        'ButtonImport
        '
        Me.ButtonImport.Animated = True
        Me.ButtonImport.CheckedState.Parent = Me.ButtonImport
        Me.ButtonImport.CustomImages.Parent = Me.ButtonImport
        Me.ButtonImport.FillColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ButtonImport.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ButtonImport.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ButtonImport.ForeColor = System.Drawing.Color.White
        Me.ButtonImport.HoverState.Parent = Me.ButtonImport
        Me.ButtonImport.Location = New System.Drawing.Point(0, 87)
        Me.ButtonImport.Name = "ButtonImport"
        Me.ButtonImport.ShadowDecoration.Parent = Me.ButtonImport
        Me.ButtonImport.Size = New System.Drawing.Size(269, 32)
        Me.ButtonImport.TabIndex = 1
        Me.ButtonImport.Text = "UPLOAD"
        '
        'FontAwesome6
        '
        Me.FontAwesome6.AutoSize = True
        Me.FontAwesome6.Font = New System.Drawing.Font("Font Awesome 5 Free Solid", 36.0!)
        Me.FontAwesome6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(166, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.FontAwesome6.HoverColor = System.Drawing.Color.Empty
        Me.FontAwesome6.IsHoverable = False
        Me.FontAwesome6.Location = New System.Drawing.Point(188, 17)
        Me.FontAwesome6.Name = "FontAwesome6"
        Me.FontAwesome6.Size = New System.Drawing.Size(58, 51)
        Me.FontAwesome6.TabIndex = 0
        Me.FontAwesome6.Text = "file-upload"
        '
        'Guna2WinProgressIndicator1
        '
        Me.Guna2WinProgressIndicator1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Guna2WinProgressIndicator1.CircleSize = 1.0!
        Me.Guna2WinProgressIndicator1.Location = New System.Drawing.Point(433, 23)
        Me.Guna2WinProgressIndicator1.MaximumSize = New System.Drawing.Size(90, 90)
        Me.Guna2WinProgressIndicator1.Name = "Guna2WinProgressIndicator1"
        Me.Guna2WinProgressIndicator1.Size = New System.Drawing.Size(90, 90)
        Me.Guna2WinProgressIndicator1.TabIndex = 1
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Century Gothic", 12.0!)
        Me.Label12.Location = New System.Drawing.Point(438, 116)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(85, 21)
        Me.Label12.TabIndex = 2
        Me.Label12.Text = "Loading..."
        '
        'LoadingPanel
        '
        Me.LoadingPanel.Controls.Add(Me.Guna2WinProgressIndicator1)
        Me.LoadingPanel.Controls.Add(Me.Label12)
        Me.LoadingPanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.LoadingPanel.Location = New System.Drawing.Point(0, 370)
        Me.LoadingPanel.Name = "LoadingPanel"
        Me.LoadingPanel.Size = New System.Drawing.Size(916, 160)
        Me.LoadingPanel.TabIndex = 3
        Me.LoadingPanel.Visible = False
        '
        'BackgroundWorkerFetchData
        '
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold)
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(36, 32)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(112, 23)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Dashboard"
        '
        'AdminHomeNotStarted
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.LoadingPanel)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Name = "AdminHomeNotStarted"
        Me.Size = New System.Drawing.Size(916, 530)
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.Guna2ShadowPanel1.ResumeLayout(False)
        Me.Guna2ShadowPanel1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Guna2ShadowPanel2.ResumeLayout(False)
        Me.Guna2ShadowPanel2.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Guna2ShadowPanel3.ResumeLayout(False)
        Me.Guna2ShadowPanel3.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Guna2ShadowPanel4.ResumeLayout(False)
        Me.Guna2ShadowPanel4.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Guna2ShadowPanel5.ResumeLayout(False)
        Me.Guna2GradientPanel1.ResumeLayout(False)
        Me.Guna2GradientPanel1.PerformLayout()
        Me.Guna2ShadowPanel6.ResumeLayout(False)
        Me.Guna2GradientPanel2.ResumeLayout(False)
        Me.Guna2GradientPanel2.PerformLayout()
        Me.LoadingPanel.ResumeLayout(False)
        Me.LoadingPanel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Guna2ShadowPanel2 As Guna.UI2.WinForms.Guna2ShadowPanel
    Friend WithEvents FontAwesome2 As Voting_SystemVB.FontAwesome
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents LabelPreviousElection As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents BtnPreviousElection As Guna.UI2.WinForms.Guna2ImageButton
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Guna2ShadowPanel3 As Guna.UI2.WinForms.Guna2ShadowPanel
    Friend WithEvents FontAwesome3 As Voting_SystemVB.FontAwesome
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents LabelParties As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents BtnParties As Guna.UI2.WinForms.Guna2ImageButton
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Guna2ShadowPanel4 As Guna.UI2.WinForms.Guna2ShadowPanel
    Friend WithEvents FontAwesome4 As Voting_SystemVB.FontAwesome
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents LabelCandidates As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents BtnCandidates As Guna.UI2.WinForms.Guna2ImageButton
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Guna2ShadowPanel1 As Guna.UI2.WinForms.Guna2ShadowPanel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents FontAwesome1 As Voting_SystemVB.FontAwesome
    Friend WithEvents LabelVotersCount As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnVoter As Guna.UI2.WinForms.Guna2ImageButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Guna2ShadowPanel5 As Guna.UI2.WinForms.Guna2ShadowPanel
    Friend WithEvents Guna2GradientPanel1 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents ButtonStartElection As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents FontAwesome5 As Voting_SystemVB.FontAwesome
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Guna2ShadowPanel6 As Guna.UI2.WinForms.Guna2ShadowPanel
    Friend WithEvents Guna2GradientPanel2 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents ButtonImport As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents FontAwesome6 As Voting_SystemVB.FontAwesome
    Friend WithEvents Guna2WinProgressIndicator1 As Guna.UI2.WinForms.Guna2WinProgressIndicator
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents LoadingPanel As System.Windows.Forms.Panel
    Friend WithEvents BackgroundWorkerFetchData As System.ComponentModel.BackgroundWorker
    Friend WithEvents Label5 As System.Windows.Forms.Label

End Class
